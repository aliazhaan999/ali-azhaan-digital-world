"use client";
import Link from "next/link";
export function SiteHeader() {
  return <header className="nav wrap">
    <Link href="/" className="brand">AA<span>.</span></Link>
    <nav>
      <Link href="/#about">About</Link><Link href="/#projects">Projects</Link>
      <Link href="/ai">ALI AI</Link><Link href="/apps">Apps</Link><Link href="/contact">Contact</Link>
    </nav>
  </header>;
}