import type { Metadata } from "next";
import "./globals.css";
import { SiteHeader } from "@/components/SiteHeader";

export const metadata: Metadata = {
  title: "Ali Azhaan | Digital World",
  description: "Personal portfolio, projects and AI assistant.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><SiteHeader />{children}<footer className="footer">© {new Date().getFullYear()} Ali Azhaan · Built with care</footer></body></html>;
}