import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return NextResponse.json({ error: "AI is not configured yet. Add GEMINI_API_KEY in your environment settings." }, { status: 503 });
    const body = await req.json();
    const messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
    const contents = messages
      .filter((m: any) => (m.role === "user" || m.role === "assistant") && typeof m.text === "string")
      .map((m: any) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.text.slice(0, 2000) }] }));
    if (!contents.length || contents[contents.length - 1].role !== "user") return NextResponse.json({ error: "Please enter a question." }, { status: 400 });

    const model = process.env.GEMINI_MODEL || "gemini-3.8-flash";
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: "You are ALI AI, a helpful, respectful educational assistant. Give clear, age-appropriate answers. Do not ask users for passwords, OTPs, or sensitive personal details. Admit uncertainty and encourage checking important facts." }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 900 }
      }),
      cache: "no-store"
    });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data?.error?.message || "The AI provider could not complete the request." }, { status: 502 });
    const reply = data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text || "").join("").trim();
    if (!reply) return NextResponse.json({ error: "The AI returned an empty response. Please try again." }, { status: 502 });
    return NextResponse.json({ reply });
  } catch { return NextResponse.json({ error: "Invalid request. Please try again." }, { status: 400 }); }
}