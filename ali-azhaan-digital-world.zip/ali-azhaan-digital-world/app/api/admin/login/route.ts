import { NextRequest, NextResponse } from "next/server";
import { createAdminToken, adminCookieName } from "@/lib/admin";
export async function POST(req: NextRequest) {
  try {
    const { password } = await req.json();
    const expected = process.env.ADMIN_PASSWORD;
    if (!expected) return NextResponse.json({ error: "Admin login is not configured." }, { status: 503 });
    if (typeof password !== "string" || password.length > 200 || password !== expected)
      return NextResponse.json({ error: "Incorrect password." }, { status: 401 });
    const res = NextResponse.json({ ok: true });
    res.cookies.set(adminCookieName, createAdminToken(), { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: 60 * 60 * 8 });
    return res;
  } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
}