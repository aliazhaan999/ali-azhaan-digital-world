"use client";
import { useState } from "react";
type Message = { role: "user" | "assistant"; text: string };
export default function AIPage() {
  const [messages, setMessages] = useState<Message[]>([{ role: "assistant", text: "Hi! I'm ALI AI. What would you like to learn about today?" }]);
  const [input, setInput] = useState(""); const [busy, setBusy] = useState(false);
  async function send(e: React.FormEvent) {
    e.preventDefault(); const q = input.trim(); if (!q || busy) return;
    const next = [...messages, { role: "user" as const, text: q }]; setMessages(next); setInput(""); setBusy(true);
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: next.slice(-12) }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || "Request failed");
      setMessages([...next, { role: "assistant", text: data.reply }]);
    } catch (err) { setMessages([...next, { role: "assistant", text: err instanceof Error ? err.message : "Something went wrong." }]); }
    finally { setBusy(false); }
  }
  return <main className="wrap page"><div className="section-label">AI LAB / 01</div><h1>ALI <span>AI</span></h1><p className="muted">An AI assistant connected through a secure server-side API.</p>
    <div className="chatbox">{messages.map((m,i)=><div key={i} className={`bubble ${m.role}`}><small>{m.role === "user" ? "YOU" : "ALI AI"}</small><p>{m.text}</p></div>)}{busy && <div className="muted">ALI AI is thinking…</div>}</div>
    <form className="chatform" onSubmit={send}><input value={input} onChange={e=>setInput(e.target.value)} maxLength={2000} placeholder="Ask me something…" aria-label="Your message"/><button className="btn primary" disabled={busy || !input.trim()}>Send</button></form>
    <p className="tiny muted">AI can make mistakes. Check important information with trusted sources. Avoid entering private information.</p>
  </main>;
}