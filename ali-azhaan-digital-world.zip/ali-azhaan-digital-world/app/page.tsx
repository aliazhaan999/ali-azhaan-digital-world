import Link from "next/link";

const projects = [
  { title: "PROJECT RAKSHAK", tag: "Student innovation", desc: "A learning project exploring how a rescue rover could support emergency responders." },
  { title: "ALI AI", tag: "AI assistant", desc: "A personal AI chat experience powered by a server-side API connection." },
  { title: "Digital World", tag: "Web development", desc: "A growing collection of useful tools, experiments and ideas." }
];

export default function Home() {
  return <main>
    <section className="hero wrap">
      <div className="eyebrow">PERSONAL WEBSITE · PORTFOLIO · AI</div>
      <h1>Hi, I'm <span>Ali Azhaan.</span><br/>Welcome to my digital world.</h1>
      <p className="lead">Student, curious learner and aspiring creator. Explore my projects, interests and experiments.</p>
      <div className="actions"><Link className="btn primary" href="/#projects">Explore my work</Link><Link className="btn" href="/ai">Try ALI AI ↗</Link></div>
      <div className="hero-orb" aria-hidden="true" />
    </section>
    <section id="about" className="section wrap">
      <div className="section-label">01 / ABOUT</div><h2>Building, learning, improving.</h2>
      <p className="muted max">This website is my public portfolio. It will grow as I build new projects, learn new skills and explore technology.</p>
      <div className="stats"><div><b>01</b><span>Curiosity</span></div><div><b>∞</b><span>Ideas to explore</span></div><div><b>2026</b><span>Keep building</span></div></div>
    </section>
    <section id="projects" className="section wrap">
      <div className="section-label">02 / SELECTED WORK</div><h2>Projects & experiments</h2>
      <div className="cards">{projects.map((p) => <article className="card" key={p.title}><div className="card-tag">{p.tag}</div><h3>{p.title}</h3><p>{p.desc}</p></article>)}</div>
    </section>
    <section className="cta wrap"><div><div className="section-label">HAVE A QUESTION?</div><h2>Talk to ALI AI.</h2><p className="muted">Ask a question and explore the AI assistant.</p></div><Link className="btn primary" href="/ai">Open AI assistant →</Link></section>
  </main>;
}