"use client";
import { useState } from "react";
export default function AppsPage() {
  const [a,setA]=useState(""), [b,setB]=useState("");
  const [note,setNote]=useState("");
  const [saved,setSaved]=useState(false);
  const x=Number(a), y=Number(b);
  return <main className="wrap page"><div className="section-label">TOOLS / 01</div><h1>Mini <span>Apps</span></h1><div className="cards">
    <section className="card"><div className="card-tag">TOOL 01</div><h3>Calculator</h3><input className="field" type="number" value={a} onChange={e=>setA(e.target.value)} placeholder="First number"/><input className="field" type="number" value={b} onChange={e=>setB(e.target.value)} placeholder="Second number"/><p className="result">Add: {a!==""&&b!==""?x+y:"—"} · Multiply: {a!==""&&b!==""?x*y:"—"}</p></section>
    <section className="card"><div className="card-tag">TOOL 02</div><h3>Quick Notes</h3><textarea className="field" rows={5} value={note} onChange={e=>{setNote(e.target.value);setSaved(false)}} placeholder="Write a reminder (stored only in this page until refreshed)…"/><button className="btn" onClick={()=>setSaved(true)}>Save on screen</button>{saved&&<p className="tiny">Saved for this session.</p>}</section>
    <section className="card"><div className="card-tag">COMING NEXT</div><h3>More tools</h3><p>Quiz, weather, QR generator and Rubik’s Cube learning tool can be added in later versions.</p></section>
  </div></main>;
}