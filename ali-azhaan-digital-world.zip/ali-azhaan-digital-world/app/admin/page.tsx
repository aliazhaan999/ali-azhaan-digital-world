import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { adminCookieName, verifyAdminToken } from "@/lib/admin";
import AdminPanel from "./panel";
export default async function AdminPage() {
  const jar = await cookies();
  if (!verifyAdminToken(jar.get(adminCookieName)?.value)) redirect("/admin/login");
  return <main className="wrap page"><div className="section-label">PRIVATE AREA</div><h1>Admin <span>Dashboard</span></h1><p className="muted">You are signed in to the starter admin area.</p><AdminPanel /></main>;
}