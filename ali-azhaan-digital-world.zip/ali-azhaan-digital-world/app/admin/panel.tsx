"use client";
export default function AdminPanel() {
  async function logout() { await fetch("/api/admin/logout", { method: "POST" }); location.href = "/"; }
  return <section className="card"><h3>Website controls</h3><p className="muted">This first version verifies private admin access. Content editing, visitor analytics and database-backed project management are planned for the next build stage.</p><button className="btn" onClick={logout}>Log out</button></section>;
}